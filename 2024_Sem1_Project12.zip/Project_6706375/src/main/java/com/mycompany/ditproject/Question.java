/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ditproject;

import java.io.Serializable;

/**
 *
 * @author Nutthapat
 */
public class Question implements Serializable {
    private String Name;
    private Choice[] Choices;
    private int QuestionScore;
    
    private static void ResetChoices(Choice[] choices) {
        for (int i=0;i<choices.length;i++) {
            choices[i] = new Choice("Answer "+(i+1),0);
        }
    }
    public Question(String Name) {
        this.Name = Name;
        this.Choices = new Choice[4];
        ResetChoices(this.Choices);
        //this.QuestionScore = QuestionScore;
    }
    
    private void Refresh() {
        int highestScore = 0;
        for (Choice ch : this.Choices) {
            if (ch.getScore() >= highestScore) {
                highestScore = ch.getScore();
            }
        }
        this.QuestionScore = highestScore;
    }
    
    public void ReplaceChoice(int index, Choice ch) {
        this.Choices[index] = ch;
        //Refresh();
    }
    
     public Choice[] getChoices() {
        return Choices;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }
    
    public int getQuestionScore() {
        Refresh();
        return this.QuestionScore;
    }
}
