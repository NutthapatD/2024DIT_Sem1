/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ditproject;

/**
 *
 * @author Nutthapat
 */
public class DITProject {

    public static void main(String[] args) {
        new Menu().setVisible(true);
    }
}
