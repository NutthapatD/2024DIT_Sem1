/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.ditproject;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.*;
import java.io.*;
import java.nio.channels.FileChannel;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Nutthapat
 */
public class EditPage extends javax.swing.JFrame {

    /**
     * Creates new form FormPage
     */
    
    Form formative;
    String formName;
    //File formFile; //THIS CAUSE ME SO MUCH PROBLEM.
    int CurrentPage = 0;
    //File formFolder; //new File("formatives");
    boolean overwrite = false;
    
    JTextField[] jChoiceBox = new JTextField[4]; //turn the jtextfield into a single array for convenience.
    JTextField[] jChoiceScoreBox = new JTextField[4]; 
    
    private Question getQuestionNow() {
        return formative.getQuestions().get(CurrentPage);
    }
    
    private void updatePage() {
        System.out.println("Updating i="+CurrentPage);
        Question q = getQuestionNow(); //formative.getQuestions().get(CurrentPage);
        Choice[] chs = q.getChoices();
        jTextPane2.setText(q.getName());
        for (int i=0;i<jChoiceBox.length;i++) {
            JTextField textbox = jChoiceBox[i];
            JTextField textscorebox = jChoiceScoreBox[i];
            Choice c = chs[i];
            textbox.setText(c.getAnswer());
            textscorebox.setText(""+c.getScore());
        }
        jLabel7.setText(q.getQuestionScore()+" score out of "+formative.getTotalScore()+" total score");
        String currentQuestionText = CurrentPage+1+"/"+formative.getQuestions().size()+" question";
        if (CurrentPage+1 > 1) { 
            currentQuestionText = currentQuestionText+"s";
        }
        jLabel8.setText(currentQuestionText);
        BackButton.setEnabled(true);
        NextButton.setEnabled(true);
        if (formative.getQuestions().size() <= 1) {
            RemoveButton.setEnabled(false);
        } else { RemoveButton.setEnabled(true); }
        if (CurrentPage <= 0) {
            BackButton.setEnabled(false);
            //NextButton.setEnabled(true);
        }
        if (CurrentPage >= formative.getQuestions().size()-1) {
            //BackButton.setEnabled(true);
            NextButton.setEnabled(false);
        }
    }
    
    private void prevPage() {
        updateAnswers();
        updateScores();
        CurrentPage -= 1;
        if (CurrentPage < 0) {
            CurrentPage = 0;
        }
        updatePage();
    }
    
    private void nextPage() {
        updateAnswers();
        updateScores();
        CurrentPage += 1;
        if (CurrentPage > formative.getQuestions().size()-1) {
            CurrentPage = formative.getQuestions().size()-1;
        }
        updatePage();
    }
    
    private void applyScoreField(int i) {
        JTextField textbox = jChoiceScoreBox[i];
        try {
            Question q = getQuestionNow();
            int score = Integer.parseInt(textbox.getText().trim());
            q.getChoices()[i].setScore(score);
            //System.out.println("Updated");
        } catch(Exception e) {
            JOptionPane.showMessageDialog(null,"Answer "+i+1+", "+e.getMessage(),"Error",JOptionPane.ERROR_MESSAGE);
        }
        //updatePage();
    }
    private void applyAnswerField(int i) {
        JTextField textbox = jChoiceBox[i];
        Question q = getQuestionNow();
        String text = textbox.getText().trim();
        q.getChoices()[i].setAnswer(text);
        //System.out.println("Updated");
        //updatePage();
    }
    
    private void toPage(int i) {
        updateAnswers();
        updateScores();
        CurrentPage = i-1;
        if (CurrentPage < 0) {
            CurrentPage = 0;
            jTextField4.setText("1");
        } else if (CurrentPage > formative.getQuestions().size()-1) {
            CurrentPage = formative.getQuestions().size()-1;
            jTextField4.setText(CurrentPage+1+"");
        }
        updatePage();
    }
    
    private boolean updateFormName() {
        String newformName = jTextField1.getText().trim();
        if (newformName.isEmpty()) {
            JOptionPane.showMessageDialog(null,"Please enter the name of the form.","Alert",JOptionPane.WARNING_MESSAGE);
            jTextField1.setText(formName);
            return false;
        } else {
            //File file = findFilesFromFolder(formFolder,formName+".txt");
            //System.out.print(file);
            
            //File oldfile = new File(formFolder.getPath()+"/"+newformName+".txt"); //findFilesFromFolder(formFolder,formName+".txt");
            //String oldFilePath = formFolder.getPath()+"/"+newformName+".txt";
            if (!Menu.existFile(newformName)) {
                //boolean success = formFile.renameTo(oldfile);
                //if (success) {
                    //https://medium.com/@AlexanderObregon/javas-files-move-method-explained-7dee1287fa92
                    boolean success = Menu.moveFile(formName,newformName);
                    if (Menu.existFile(formName+FormPage.saveRegex+"SaveResult")) {
                        Menu.moveFile(formName+FormPage.saveRegex+"SaveResult",newformName+FormPage.saveRegex+"SaveResult");
                    }
                    //rename saveresult
                    if (success) { formName = newformName; }
                    return success;
                    /*try {
                        Files.move(Paths.get(formFile.getPath()), Paths.get(oldfile.getPath()));
                        //System.out.println("File moved successfully.");
                        formFile = new File(oldfile.getPath());
                        Menu.manuallyChangeFile(formName,newformName);
                        formName = newformName;
                        JOptionPane.showMessageDialog(null,"Successfully renamed to "+formName+".txt","Alert",JOptionPane.WARNING_MESSAGE); 
                    } catch (IOException e) {
                        //System.err.println("Move failed: " + e.getMessage());
                        JOptionPane.showMessageDialog(null,e.getMessage(),"Alert",JOptionPane.WARNING_MESSAGE); 
                        return false;
                    }*/
                    //I attempted to use .renameTo but it doesnt work so I decided to find loophole.
                    /*try {
                        if (formFile.exists()) {
                            copyFile(formFile,oldfile);
                            formFile.delete();
                            formFile.deleteOnExit();
                            oldfile.createNewFile();
                        }
                        formFile = oldfile;
                        formName = newformName;
                        JOptionPane.showMessageDialog(null,"Successfully renamed to "+formName+".txt","Alert",JOptionPane.WARNING_MESSAGE); 
                        Menu.updateListFile();
                    } catch (IOException io) {
                        JOptionPane.showMessageDialog(null,io.getMessage(),"Alert",JOptionPane.WARNING_MESSAGE); 
                    }*/
                //} else {
                //   JOptionPane.showMessageDialog(null,"Unable to rename "+formName+".txt","Alert",JOptionPane.WARNING_MESSAGE); 
                //}
            } else {
                JOptionPane.showMessageDialog(null,"File "+newformName+".txt already exist in directory.","Alert",JOptionPane.WARNING_MESSAGE);
                jTextField1.setText(formName);
                return false;
            }
        }
        //return true;
    }
    
    private void updateAnswers() {
        for (int i=0;i<jChoiceBox.length;i++) {
            applyAnswerField(i);
        }
        //updatePage();
    }
    private void updateScores() {
        for (int i=0;i<jChoiceScoreBox.length;i++) {
            applyScoreField(i);
        }
        //updatePage();
    }
    
    private void resetScore() {
        for (JTextField textscorebox : jChoiceScoreBox) {
            //JTextField textbox = jChoiceBox[i];
            //textbox.setText("Answer "+i); //reset answer to "Answer i" and update.
            textscorebox.setText("0"); //reset score to 0 and update.
        }
        updateScores();
    }
    
    private void newPage() {
        formative.addQuestion(CurrentPage+1,new Question("Question "+(formative.getQuestions().size()+1)));
        nextPage();
    }
    private void removePage() {
        if (formative.getQuestions().size() > 1) {
            formative.removeQuestion(CurrentPage);
            if (CurrentPage < 0) {
                CurrentPage = 0;
            jTextField4.setText("1");
            } else if (CurrentPage > formative.getQuestions().size()-1) {
                CurrentPage = formative.getQuestions().size()-1;
                jTextField4.setText(CurrentPage+1+"");
            }
            updatePage();
        }
    }
    
    //
    
    public void SaveForm(File file) {
        //File file = findFilesFromFolder(folder,formName,true);
        updatePage(); //update the page one more time before saving.
        //boolean nameSuccess = updateFormName();
        //if (nameSuccess) {
        try {
            PrintStream out = new PrintStream(file);
            //out.println(formative.getTotalScore());
            //out.println("//");
            for (Question q : formative.getQuestions()) {
                out.println(q.getName());
                out.println("**");
                for (Choice ch : q.getChoices()) {
                    //out.println("");
                    out.println(ch.getAnswer());
                    out.println("*/");
                    out.println(ch.getScore());
                    out.println("*/");
                }
                out.println("//");
            }
            JOptionPane.showMessageDialog(null,"Successfully saved!");
            Menu.manuallyChangeFile(formName,formName);
            out.close();
            this.dispose();
            //Menu.updateListFile();
        } catch(IOException io) {
            JOptionPane.showMessageDialog(null,io.getMessage(),"Alert",JOptionPane.WARNING_MESSAGE);
        }
        //}
    }
    
    public void UpdateData() {
        Question q = getQuestionNow();
        updateAnswers();
        updateScores();
        q.setName(jTextPane2.getText());
    }
    
    public void SaveForm() { SaveForm(Menu.getFile(formName)); }
    
    //https://stackoverflow.com/questions/5388146/copy-and-rename-file-on-different-location
     public void copyFile(File sourceFile, File destFile) throws IOException {
        if(!destFile.exists()) {
         destFile.createNewFile();
        }

        FileChannel source = null;
        FileChannel destination = null;
        try {
         source = new RandomAccessFile(sourceFile,"rw").getChannel();
         destination = new RandomAccessFile(destFile,"rw").getChannel();

         long position = 0;
         long count    = source.size();

         source.transferTo(position, count, destination);
        }
        finally {
         if(source != null) {
          source.close();
         }
         if(destination != null) {
          destination.close();
         }
       }
    }
    
    //from https://stackoverflow.com/questions/1844688/how-can-i-read-all-files-in-a-folder-from-java
    //Modified.
    
    //You can just do file.exist()
    /*public File findFilesFromFolder(File folder,String name,boolean createOnNull) {
        File result = null;
        for (File file : folder.listFiles()) {
            if (file.getName().equals(name)) {
                result = file;
                break;
            }
        }
        if (result == null && createOnNull) {
            result = new File(folder.getPath()+"/"+name+".txt");
        }
        return result;
    }
    private File findFilesFromFolder(File folder,String name) { //way to overload the method.
        return findFilesFromFolder(folder,name,false);
    }
    
    public ArrayList<File> listFilesFromFolder(File folder) {
        ArrayList<File> result = new ArrayList();
        for (final File fileEntry : folder.listFiles()) {
            result.add(fileEntry);
        }
        return result;
    }*/
    
    //
    
    public EditPage() {
        initComponents();
        this.setLocationRelativeTo(null); //https://stackoverflow.com/questions/15812191/set-jframe-to-center-of-screen-in-netbeans
        
        jChoiceBox[0] = jTextField6;
        jChoiceBox[1] = jTextField7;
        jChoiceBox[2] = jTextField12;
        jChoiceBox[3] = jTextField9;
        jChoiceScoreBox[0] = jTextField5;
        jChoiceScoreBox[1] = jTextField8;
        jChoiceScoreBox[2] = jTextField11;
        jChoiceScoreBox[3] = jTextField10;
        
        //formFolder = Menu.formFolder;
        formName = Menu.formName; //copy formName so it doesnt get updated during the edit.
        //if (!formFolder.exists()){
        //    formFolder.mkdirs(); //create new folder
        //}
           
        formative = new Form(formName);
        //formFile = new File(formFolder.getPath()+"/"+formName+".txt");
            
        if (Menu.isNewForm) {
            formative.addQuestion(new Question("Question 1"));
            //try {
                /*if (!formFile.exists()){
                    formFile.createNewFile();
                }*/
            //} catch(IOException io) {
            //    JOptionPane.showMessageDialog(null,io.getMessage(),"Alert",JOptionPane.WARNING_MESSAGE);
            //}
        } else {
            overwrite = true;
            //File file = findFilesFromFolder(formFolder,formName+".txt");
            if (!Menu.existFile(formName)) { //(!formFile.exists()) {
                JOptionPane.showMessageDialog(null,formName+".txt doesn't exist in directory.","Alert",JOptionPane.WARNING_MESSAGE);
            } else {
                Menu.PopulateForm(formName,formative);
            }
        }
        jTextField1.setText(formName);
        
        //https://stackoverflow.com/questions/21330682/confirmation-before-press-yes-to-exit-program-in-java
        //https://www.youtube.com/watch?v=GTFQi5McbzE
        this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        this.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                int confirmed = JOptionPane.showConfirmDialog(null, 
                    "Are you sure you want to leave without saving?", "Closing",
                    JOptionPane.YES_NO_OPTION,JOptionPane.WARNING_MESSAGE);
                if (confirmed == JOptionPane.YES_OPTION) {
                    if (!overwrite) {
                        Menu.deleteFile(formName);
                        //formFile.delete();
                        //formFile.deleteOnExit();
                    }
                    e.getWindow().dispose();
                    //Menu.updateListFile();
                } else {
                    
                }
            }
          }
        );

        Menu.createFile(formName);
        //updateFormName();
        updatePage();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        CardPanel = new javax.swing.JPanel();
        Choice = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextPane2 = new javax.swing.JTextPane();
        jLabel3 = new javax.swing.JLabel();
        BackButton = new javax.swing.JButton();
        NextButton = new javax.swing.JButton();
        SaveButton = new javax.swing.JButton();
        jTextField4 = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jButton5 = new javax.swing.JButton();
        jTextField5 = new javax.swing.JTextField();
        jTextField6 = new javax.swing.JTextField();
        jTextField7 = new javax.swing.JTextField();
        jTextField8 = new javax.swing.JTextField();
        jTextField9 = new javax.swing.JTextField();
        jTextField10 = new javax.swing.JTextField();
        jTextField11 = new javax.swing.JTextField();
        jTextField12 = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        RemoveButton = new javax.swing.JButton();
        AddButton = new javax.swing.JButton();
        ResetButton = new javax.swing.JButton();
        RefreshButton = new javax.swing.JButton();
        RenameButton1 = new javax.swing.JButton();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        CardPanel.setLayout(new java.awt.CardLayout());

        jTextPane2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTextPane2.setText("This is question number. What is the answer of this question? Is it....");
        jTextPane2.setToolTipText("");
        jScrollPane2.setViewportView(jTextPane2);

        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        jLabel3.setText("Question:");

        BackButton.setText("Back");
        BackButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackButtonActionPerformed(evt);
            }
        });

        NextButton.setText("Next");
        NextButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NextButtonActionPerformed(evt);
            }
        });

        SaveButton.setText("Save");
        SaveButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SaveButtonActionPerformed(evt);
            }
        });

        jTextField4.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField4.setText("0");

        jLabel7.setText("000/000 total score");

        jButton5.setText("Go");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jTextField5.setText("0");
        jTextField5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField5ActionPerformed(evt);
            }
        });

        jTextField6.setText("Answer 1");
        jTextField6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField6ActionPerformed(evt);
            }
        });

        jTextField7.setText("Answer 2");
        jTextField7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField7ActionPerformed(evt);
            }
        });

        jTextField8.setText("0");
        jTextField8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField8ActionPerformed(evt);
            }
        });

        jTextField9.setText("Answer 4");
        jTextField9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField9ActionPerformed(evt);
            }
        });

        jTextField10.setText("0");
        jTextField10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField10ActionPerformed(evt);
            }
        });

        jTextField11.setText("0");
        jTextField11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField11ActionPerformed(evt);
            }
        });

        jTextField12.setText("Answer 3");
        jTextField12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField12ActionPerformed(evt);
            }
        });

        jLabel8.setText("000/000 questions");

        jTextField1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jTextField1.setText("FormName");
        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });

        RemoveButton.setText("Remove");
        RemoveButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RemoveButtonActionPerformed(evt);
            }
        });

        AddButton.setText("Add");
        AddButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddButtonActionPerformed(evt);
            }
        });

        ResetButton.setText("Reset");
        ResetButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ResetButtonActionPerformed(evt);
            }
        });

        RefreshButton.setText("Refresh");
        RefreshButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RefreshButtonActionPerformed(evt);
            }
        });

        RenameButton1.setText("Rename");
        RenameButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RenameButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout ChoiceLayout = new javax.swing.GroupLayout(Choice);
        Choice.setLayout(ChoiceLayout);
        ChoiceLayout.setHorizontalGroup(
            ChoiceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, ChoiceLayout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(ChoiceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(ChoiceLayout.createSequentialGroup()
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(jScrollPane2)
                    .addGroup(ChoiceLayout.createSequentialGroup()
                        .addGroup(ChoiceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextField7)
                            .addComponent(jTextField6, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jTextField9)
                            .addComponent(jTextField12, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(ChoiceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextField11, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField10, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField8, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(ChoiceLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(ChoiceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(ChoiceLayout.createSequentialGroup()
                                .addComponent(BackButton, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(AddButton, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(RemoveButton, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(10, 10, 10)
                                .addComponent(SaveButton, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(NextButton, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(ChoiceLayout.createSequentialGroup()
                                .addComponent(RefreshButton)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(ResetButton))
                            .addGroup(ChoiceLayout.createSequentialGroup()
                                .addComponent(jTextField1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(RenameButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addGap(27, 27, 27))
        );
        ChoiceLayout.setVerticalGroup(
            ChoiceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ChoiceLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(ChoiceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jTextField1)
                    .addComponent(RenameButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(ChoiceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton5)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(ChoiceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ResetButton)
                    .addComponent(RefreshButton))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(ChoiceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(ChoiceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(ChoiceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextField12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(ChoiceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextField9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(9, 9, 9)
                .addGroup(ChoiceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(BackButton, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(NextButton, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(AddButton, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(RemoveButton, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(SaveButton, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(16, Short.MAX_VALUE))
        );

        CardPanel.add(Choice, "card3");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(CardPanel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(CardPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BackButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BackButtonActionPerformed
        // TODO add your handling code here:
        UpdateData();
        prevPage();
    }//GEN-LAST:event_BackButtonActionPerformed

    private void NextButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NextButtonActionPerformed
        // TODO add your handling code here:
        UpdateData();
        nextPage();
    }//GEN-LAST:event_NextButtonActionPerformed

    private void SaveButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SaveButtonActionPerformed
        // TODO add your handling code here:
        UpdateData();
        SaveForm();
    }//GEN-LAST:event_SaveButtonActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:
        try {
            int pageNum = Integer.parseInt(jTextField4.getText().trim());
            toPage(pageNum);
        } catch(Exception e) {
            JOptionPane.showMessageDialog(null,e.getMessage(),"Error",JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jTextField5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField5ActionPerformed
        // TODO add your handling code here:
        //applyScoreField(0);
        UpdateData();
        updatePage();
    }//GEN-LAST:event_jTextField5ActionPerformed

    private void jTextField8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField8ActionPerformed
        // TODO add your handling code here:
        //applyScoreField(1);
        UpdateData();
        updatePage();
    }//GEN-LAST:event_jTextField8ActionPerformed

    private void jTextField10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField10ActionPerformed
        // TODO add your handling code here:
        //applyScoreField(3);
        UpdateData();
        updatePage();
    }//GEN-LAST:event_jTextField10ActionPerformed

    private void jTextField11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField11ActionPerformed
        // TODO add your handling code here:
        //applyScoreField(2);
        UpdateData();
        updatePage();
    }//GEN-LAST:event_jTextField11ActionPerformed

    private void RemoveButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RemoveButtonActionPerformed
        // TODO add your handling code here:
        removePage();
    }//GEN-LAST:event_RemoveButtonActionPerformed

    private void jTextField12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField12ActionPerformed
        // TODO add your handling code here:
        //applyAnswerField(2);
        UpdateData();
        updatePage();
    }//GEN-LAST:event_jTextField12ActionPerformed

    private void AddButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddButtonActionPerformed
        // TODO add your handling code here:
        newPage();
    }//GEN-LAST:event_AddButtonActionPerformed

    private void ResetButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ResetButtonActionPerformed
        // TODO add your handling code here:
        resetScore();
        updatePage();
    }//GEN-LAST:event_ResetButtonActionPerformed

    private void jTextField6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField6ActionPerformed
        // TODO add your handling code here:
        //applyAnswerField(0);
        UpdateData();
        updatePage();
    }//GEN-LAST:event_jTextField6ActionPerformed

    private void jTextField7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField7ActionPerformed
        // TODO add your handling code here:
        //applyAnswerField(1);
        UpdateData();
        updatePage();
    }//GEN-LAST:event_jTextField7ActionPerformed

    private void jTextField9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField9ActionPerformed
        // TODO add your handling code here:
        //applyAnswerField(3);
        UpdateData();
        updatePage();
    }//GEN-LAST:event_jTextField9ActionPerformed

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
        updateFormName();
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void RefreshButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RefreshButtonActionPerformed
        // TODO add your handling code here:
        UpdateData();
        updatePage();
    }//GEN-LAST:event_RefreshButtonActionPerformed

    private void RenameButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RenameButton1ActionPerformed
        // TODO add your handling code here:
        updateFormName();
    }//GEN-LAST:event_RenameButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EditPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EditPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EditPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EditPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EditPage().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AddButton;
    private javax.swing.JButton BackButton;
    private javax.swing.JPanel CardPanel;
    private javax.swing.JPanel Choice;
    private javax.swing.JButton NextButton;
    private javax.swing.JButton RefreshButton;
    private javax.swing.JButton RemoveButton;
    private javax.swing.JButton RenameButton1;
    private javax.swing.JButton ResetButton;
    private javax.swing.JButton SaveButton;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField10;
    private javax.swing.JTextField jTextField11;
    private javax.swing.JTextField jTextField12;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JTextField jTextField8;
    private javax.swing.JTextField jTextField9;
    private javax.swing.JTextPane jTextPane2;
    // End of variables declaration//GEN-END:variables
}
