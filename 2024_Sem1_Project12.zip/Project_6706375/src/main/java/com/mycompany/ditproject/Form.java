/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ditproject;

import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author Nutthapat
 */
public class Form implements Serializable {
    private String Name;
    private ArrayList<Question> Questions;
    private int TotalScore;
    //private boolean changed; 
    //I initially want it to update only when something changed but read line 56> for more detail.

    public Form(String Name) {
        this.Name = Name;
        this.Questions = new ArrayList();
        this.TotalScore = 0;
        //this.changed = true;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    private void Refresh() {
        //if (changed) {
            int totalScore = 0;
            for (int i=0;i<this.Questions.size();i++) {
                Question q = this.Questions.get(i);
                totalScore += q.getQuestionScore();
            }
            this.TotalScore = totalScore;
        //}
    }
    
    public int getTotalScore() {
        Refresh();
        return TotalScore;
    }
    
    /*public void setTotalScore(int Score) {
        this.TotalScore = Score;
    }*/
    
    //I want it to update everytime something changes but theres too many class that to  need to be tracked.
    //so its better to just make the total score update everytime the function is called.
    public void addQuestion(Question question) {
        //this.changed = true;
        this.Questions.add(question);
    }
    public void addQuestion(int index,Question question) {
        //this.changed = true;
        this.Questions.add(index,question);
    }
    public void removeQuestion(int index) {
        //this.changed = true;
        this.Questions.remove(index);
    }
    public ArrayList<Question> getQuestions() {
        return Questions;
    }
    
    //Handled by Question class.
    /*public void newQuestion(int index, String name, Choice c1,Choice c2,Choice c3,Choice c4) {
        
    }
    public void newQuestion(String name, Choice c1,Choice c2,Choice c3,Choice c4) {
        
    }*/
}
