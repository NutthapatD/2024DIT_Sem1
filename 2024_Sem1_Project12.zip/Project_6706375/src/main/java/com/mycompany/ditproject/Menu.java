/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.ditproject;

import java.io.File;
import java.io.IOException;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.Scanner;
import javax.swing.JList;
import javax.swing.JOptionPane;

/**
 *
 * @author Nutthapat
 */
public class Menu extends javax.swing.JFrame {

    /**
     * Creates new form Menu
     */
    
    static public File formFolder = new File("formatives");
    
    static public boolean isNewForm = true;
    static public String formName = "FormName";
    
    static public JList[] fileLists;
    static public ArrayList<File> files;
    
    static String _jselected; //specifically to apply selection on the list.
    private void ShowSelectedjList() {
        _jselected = jList1.getSelectedValue();
       //System.out.println(_jselected);
        if (_jselected == null || _jselected.isEmpty() ) {
            _jselected = "None";
        }
        jLabel3.setText("Current selected: "+_jselected); 
        _jselected = jList3.getSelectedValue();
       //System.out.println(_jselected);
        if (_jselected == null || _jselected.isEmpty()) {
            _jselected = "None";
        }
        jLabel5.setText("Current selected: "+_jselected); 
    }
    
    public static File getFile(File directory,String fileName) {
        File result = null;
        System.out.println(directory);
        for (File file : directory.listFiles()) {
            if (file.getName().equals(fileName+".txt")) {
                result = file;
            }
        }
        return result;
    }
    public static File getFile(String fileName) {
        File result = null;
        for (File file : files) {
            if (file.getName().equals(fileName+".txt")) {
                result = file;
            }
        }
        return result;
    }
    
    public static boolean existFile(String fileName) {
        File file = getFile(fileName);
        if (file == null) {
            return false;
        } else {
            return file.exists();
        }
    }
    public static boolean moveFile(String source,String dest,boolean showMessage) {
        try {
            //System.out.println(formFolder.getPath()+"/"+source+".txt");
            //System.out.println(formFolder.getPath()+"/"+dest+".txt");
            Files.move(Paths.get(formFolder.getPath()+"/"+source+".txt"), Paths.get(formFolder.getPath()+"/"+dest+".txt"));
            //System.out.println("File moved successfully.");
            if (showMessage) {
                JOptionPane.showMessageDialog(null,"Successfully renamed to "+dest+".txt","Alert",JOptionPane.WARNING_MESSAGE); 
            }
        } catch (IOException e) {
            //System.err.println("Move failed: " + e.getMessage());
            JOptionPane.showMessageDialog(null,e.getMessage(),"Alert",JOptionPane.WARNING_MESSAGE); 
            return false;
        }
        updateListFile();
        return true;
    }
    public static boolean moveFile(String source,String dest) {
        return moveFile(source,dest,true);
    }
    
    public static void updateListFile() {
        ArrayList<String> results = new ArrayList();
        for (File file : formFolder.listFiles()) {
            String[] n = file.getName().split("\\."); //extract file extension.
            results.add(n[0]);
            boolean exist = false;
            for (File otherFile : files) {
                if (otherFile.equals(file)) {
                    exist = true;
                }
            }
            if (!exist) {files.add(file);}
        }
        for (int i=0;i<results.size();) {
            System.out.println(results.get(i));
            System.out.println(FormPage.saveRegex+"SaveResult");
            System.out.println(results.get(i).indexOf(FormPage.saveRegex+"SaveResult"));
            if (!results.get(i).contains(FormPage.saveRegex+"SaveResult")) {
                i++;
            } else { results.remove(i); } //remove all saveresult file from being displayed.
        }
        String[] arrayResult = results.toArray(new String[results.size()]);
        for (JList jList : fileLists) {
            //if (!n[0].matches("(.*)&SaveResult.txt(.*)")) {
            jList.setListData(arrayResult);
            //}
        }
    }
    
    public static boolean createFile(File directory, String fileName) {
        try {
            if (!existFile(fileName)) {
                File newFile = new File(directory.getPath()+"/"+fileName+".txt");
                newFile.createNewFile();
                updateListFile();
            }
        } catch( IOException io ) {
            System.err.println(io.getMessage());
            return false;
        }
        return true;
    }
    public static boolean createFile(String fileName) {
        return createFile(formFolder,fileName);
    }
    
    public static void deleteFile(String fileName,boolean hideMessage) {
        try {
            File file = getFile(fileName);
            if (existFile(fileName)) {
                //Files.move(Paths.get(file.getPath()), Paths.get(file.getPath())); //force the IOException.
                if (existFile(fileName+FormPage.saveRegex+"SaveResult")) { //delete the saved result too.
                    deleteFile(fileName+FormPage.saveRegex+"SaveResult",true);
                }
                Files.delete(Paths.get(file.getPath()));
                updateListFile();
                if (!hideMessage) {
                    JOptionPane.showMessageDialog(null,"Successfully deleted "+fileName+".txt!");
                }
            }
        } catch(Exception e) {
            JOptionPane.showMessageDialog(null,e.getMessage(),"Alert",JOptionPane.WARNING_MESSAGE);
        }
    }
    public static void deleteFile(String fileName) {
        deleteFile(fileName,false);
    }
    
    
    private static String WriteStringUntilBreak(Scanner sc,String breaker) {
        StringBuilder text = new StringBuilder();
        while (sc.hasNext()) {
            String ln = sc.nextLine();
            System.out.print(ln);
            if (ln.equals(breaker)) {
                break;
            } else {
                text.append(ln);
                text.append("\n");
            }
        }
        return text.toString().trim();
    }
    
    public static void PopulateForm(String formName, Form formative) { //initially called "ReadForm"
        //File file = findFilesFromFolder(formFolder,formName+".txt");
        /*if (file == null) {
            JOptionPane.showMessageDialog(null,formName+".txt doesn't exist in directory.","Alert",JOptionPane.WARNING_MESSAGE);
        } else {
            
        }*/
        try {
            Scanner sc = new Scanner(getFile(formName));
            //ArrayList<Question> questions = formative.getQuestions();
            while (sc.hasNext()) {
                String questionName = WriteStringUntilBreak(sc,"**");
                Question newQuestion = new Question(questionName);
                Choice[] choices = newQuestion.getChoices();
                for (Choice choice : choices) {
                    String answer = WriteStringUntilBreak(sc,"*/");
                    int score = Integer.parseInt(WriteStringUntilBreak(sc,"*/"));
                    choice.setAnswer(answer);
                    choice.setScore(score);
                }
                formative.addQuestion(newQuestion);
                WriteStringUntilBreak(sc,"//");
            }
            sc.close();
        } catch(IOException e) {
            JOptionPane.showMessageDialog(null,e.getMessage(),"Error",JOptionPane.ERROR_MESSAGE);
        }
    }
    
    
    public static void manuallyChangeFile(String source,String dest) {
        ArrayList<String> results = new ArrayList();
        boolean exist = false;
        //for (JList jList : fileLists) {
        for (int i = 0; i< fileLists[0].getModel().getSize();i++) {
            String e = String.valueOf(fileLists[0].getModel().getElementAt(i));
            if (e.equals(source)) {
                exist = true;
                results.add(dest);
            } else {results.add(e);}
        }
        //}
        if (!exist) { results.add(dest); }
        String[] arrayResult = results.toArray(new String[results.size()]);
        for (JList jList : fileLists) {
            jList.setListData(arrayResult);
        }
    }
    
    //
    
    public Menu() {
        initComponents();
        this.setLocationRelativeTo(null); //https://stackoverflow.com/questions/15812191/set-jframe-to-center-of-screen-in-netbeans
        
        if (!formFolder.exists()){
            formFolder.mkdirs(); //create new folder
        }
        
        files = new ArrayList();
        fileLists = new JList[2];
        fileLists[0] = jList1;
        fileLists[1] = jList3;
        updateListFile();
        
        ShowSelectedjList();
         //https://stackoverflow.com/questions/62349501/listselectionlistener-does-not-fire-events-when-calling-setselected-methods
        jList1.addListSelectionListener(e -> {
            if(!e.getValueIsAdjusting()) {
                ShowSelectedjList();
            }
        });
        jList3.addListSelectionListener(e -> {
            if(!e.getValueIsAdjusting()) {
                ShowSelectedjList();
            }
        });
        
        //cheesy way to make jlist static
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jList1 = new javax.swing.JList<>();
        jTextField1 = new javax.swing.JTextField();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        Refresh1 = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jList3 = new javax.swing.JList<>();
        jButton9 = new javax.swing.JButton();
        jButton10 = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        Refresh2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Welcome to formative maker!");

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Go to Edit to start making your own formative or take the Test that you or someone else make!");
        jLabel1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, 779, Short.MAX_VALUE)
                .addContainerGap())
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(145, 145, 145)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel1)
                .addContainerGap(228, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Home", jPanel1);

        jLabel3.setText("jLabel1");

        jList1.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane1.setViewportView(jList1);

        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });

        jButton2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton2.setText("New");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton3.setText("Edit");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton4.setText("Delete");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        Refresh1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        Refresh1.setText("Refresh");
        Refresh1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Refresh1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jTextField1, javax.swing.GroupLayout.DEFAULT_SIZE, 633, Short.MAX_VALUE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 208, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(Refresh1))
                    .addComponent(jScrollPane1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton3, javax.swing.GroupLayout.DEFAULT_SIZE, 124, Short.MAX_VALUE)
                    .addComponent(jButton4, javax.swing.GroupLayout.DEFAULT_SIZE, 124, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
                    .addComponent(jTextField1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(Refresh1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 343, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jButton3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton4)))
                .addGap(36, 36, 36))
        );

        jTabbedPane1.addTab("Edit", jPanel2);

        jList3.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane3.setViewportView(jList3);

        jButton9.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton9.setText("Begin Test");
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });

        jButton10.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton10.setText("Check Answers");
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });

        jLabel5.setText("jLabel1");

        Refresh2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        Refresh2.setText("Refresh");
        Refresh2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Refresh22ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 208, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(Refresh2))
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 633, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Refresh2)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 387, Short.MAX_VALUE)
                        .addGap(36, 36, 36))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jButton9)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton10)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );

        jTabbedPane1.addTab("Test", jPanel3);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTabbedPane1)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1, javax.swing.GroupLayout.Alignment.TRAILING)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        // TODO add your handling code here:
        String selected = jList3.getSelectedValue();
        if (selected == null || selected.isEmpty()) {
            JOptionPane.showMessageDialog(null,"Please select a form to test.");
        } else {
            formName = selected.trim();
            new FormPage().setVisible(true);
        }
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        isNewForm = true;
        formName = jTextField1.getText().trim();
        if (formName.isEmpty()) {
            JOptionPane.showMessageDialog(null,"Please enter the name of the form.");
        } else {
            File oldfile = new File(formFolder.getPath()+"/"+formName+".txt"); //findFilesFromFolder(formFolder,formName+".txt");
            if (oldfile.exists()) {
                JOptionPane.showMessageDialog(null,formName+".txt already exist in directory.","Alert",JOptionPane.WARNING_MESSAGE);
            } else {
                new EditPage().setVisible(true);
            }
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        isNewForm = false;
        /*formName = jTextField1.getText().trim();
        if (formName.isEmpty()) {
            JOptionPane.showMessageDialog(null,"Please enter the name of the form.");
        } else {
            new EditPage().setVisible(true);
        }*/
        String selected = jList1.getSelectedValue();
        if (selected == null || selected.isEmpty()) {
            JOptionPane.showMessageDialog(null,"Please select a form to edit.");
        } else {
            formName = selected.trim();
            new EditPage().setVisible(true);
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void Refresh1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Refresh1ActionPerformed
        // TODO add your handling code here:
        updateListFile();
    }//GEN-LAST:event_Refresh1ActionPerformed

    private void Refresh22ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Refresh22ActionPerformed
        // TODO add your handling code here:
        updateListFile();
    }//GEN-LAST:event_Refresh22ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
        String selected = jList1.getSelectedValue();
        if (selected == null || selected.isEmpty()) {
            JOptionPane.showMessageDialog(null,"Please select a form to delete.");
        } else {
            deleteFile(selected);
        }
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
        // TODO add your handling code here:
        String selected = jList3.getSelectedValue();
        if (selected == null || selected.isEmpty()) {
            JOptionPane.showMessageDialog(null,"Please select a form to check.");
        } else {
            formName = selected.trim();
            new AnswersPage().setVisible(true);
        }
    }//GEN-LAST:event_jButton10ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Menu().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Refresh1;
    private javax.swing.JButton Refresh2;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JList<String> jList1;
    private javax.swing.JList<String> jList3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTextField jTextField1;
    // End of variables declaration//GEN-END:variables
}
