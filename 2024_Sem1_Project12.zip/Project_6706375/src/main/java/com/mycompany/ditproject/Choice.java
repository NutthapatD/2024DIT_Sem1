/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ditproject;

import java.io.Serializable;

/**
 *
 * @author Nutthapat
 */
public class Choice implements Serializable {
    private String Answer;
    private int Score;

    public Choice(String Answer, int Score) {
        this.Answer = Answer;
        this.Score = Score;
    }

    public String getAnswer() {
        return Answer;
    }

    public void setAnswer(String Answer) {
        this.Answer = Answer;
    }

    public int getScore() {
        return Score;
    }

    public void setScore(int Score) {
        this.Score = Score;
    }
}
